package com.cg.billing.beans;

import javax.persistence.Embeddable;

@Embeddable
public class Address {
	
	private String city, state;
	private int pinCode;
	public Address() {}
	
	public Address(String city, String state, int pinCode) {
		super();
		this.city = city;
		this.state = state;
		this.pinCode = pinCode;
	}
}