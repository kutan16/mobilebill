package com.cg.billing.beans;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
@Entity
public class Plan {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int planID;
	private int monthlyRental, freeLocalCalls, freeStdCalls, freeLocalSMS, freeStdSMS, freeInternetDataUsageUnits;
	private float localCallRate, stdCallRate, localSMSRate, stdSMSRate, internetDataUsageRate;
	private String planCircle, planName;
	@OneToMany(mappedBy="plan",cascade=CascadeType.ALL)
	@MapKey
	private Map<Long, PostpaidAccount> accounts;
	
	public Plan() {}

}